# 04_TankBattle
An open world head to head tank battle with simple AI and advanced control in Unreal 4.14.3 

## Lecture List
* initial github repository

